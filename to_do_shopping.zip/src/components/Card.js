import { useState } from "react";
import React from "react";
import axios from 'axios';

// {produto} -> props para produto

export default function Card({produto}) {

    const [check, setCheck] = useState(false);

    const checkProduto = async (id, check) => {
        try {
            const _id = id;
            const _check = !check;

            // alert(_check);

            await axios.patch("http://localhost:4200/produtos/1",
            {
                // id: _id,
                check: _check
            });

            setCheck(_check);

        } catch (erro) {
            alert(erro);
        }
    }


    let _className = "";

    // if (check == true) {
    if (produto.check == true) {
        _className = "w3-deep-orange w3-container w3-round-large";
    } else {
        _className = "w3-container w3-round-large";
    }

    return (
        <div className="card" >
            <div className="w3-col s3 m2 l1 w3-container" style={{padding: "1px"}} >
                <div className= {_className} style={{padding: "6px"}} >
                    <img className="w3-card-4 w3-round-large" 
                        src={produto.imagem} style={{width: "100%"}}
                        onClick={ () => checkProduto( produto.id, produto.check ) } 
                        />
                </div>
            </div>
        </div>
    );
}