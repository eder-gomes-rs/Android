
import React, { useEffect, useState } from "react";
import Card from "./Card";
import API from "../service/Api.js";

export default function ListProdutos() {

    const [produtos, setProdutos] = useState([]);

    useEffect( () => {
        API.get("produtos")
            .then( (response) => setProdutos(response.data) )
            .catch( (err) => alert(err) );
    } )

    return (
        <section class="w3-row w3-container ">
            {
                produtos.map( prod => 
                    <Card key={prod.id} produto = {prod}>
                    </Card>
                )
            }
        </section>
    )
}
