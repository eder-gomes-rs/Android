
import './App.css';
import ListProdutos from './components/ListProdutos';

function App() {
  return (
    <>
      <header>
        <div className="w3-container w3-blue">
          <h2>To Do Shopping</h2>
        </div>
      </header>

      <main>
        <div className="App">

          <div id="produtos" className="w3-container ">
            <ListProdutos></ListProdutos>
          </div>

        </div>
      </main>

      <footer>
        <div className="w3-container w3-blue w3-bottom w3-center">
          <h2> --- Sua Marca Aqui! ---</h2>
        </div>
      </footer>
    </>
  );
}

export default App;
