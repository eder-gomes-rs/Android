package br.senac.appfinanceiro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.senac.appfinanceiro.adapter.ListaAdapter
import br.senac.appfinanceiro.databinding.ActivityListaBinding
import br.senac.appfinanceiro.model.Lancamentos
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class listaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListaBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_lista)
        setContentView(binding.root)

        //binding.rvLista = findViewById(R.id.rvLista)
        val rvLista = findViewById<RecyclerView>(R.id.rvLista)
    }

    override fun onResume() {
        super.onResume()

        val db = FirebaseFirestore.getInstance()

        db.collection("lancamentos").get()
            .addOnSuccessListener { result ->

                var lista : ArrayList<Lancamentos> = ArrayList()

                for (document in result) {

                    val lancamento = Lancamentos()

                    lancamento.dtData = document.data.get("dtData").toString()
                    lancamento.historico = document.data.get("historico").toString()
                    lancamento.valor = document.data.get("valor").toString()
                    lancamento.tipo = document.data.get("tipo").toString()

                    lista.add(lancamento)

                }

                val _rvLista = ListaAdapter(lista,this)

                val rvLista = findViewById<RecyclerView>(R.id.rvLista)
                val linearLayoutManager = LinearLayoutManager(this)
                rvLista.layoutManager = linearLayoutManager
                rvLista.adapter = _rvLista
            }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var itemSelecionado = ""

        when(item?.itemId) {
            R.id.lancamentos -> itemSelecionado = "Lançamentos"
            R.id.relatorio -> itemSelecionado = "Relatorio"
            R.id.sair -> itemSelecionado = "Sair"
        }

        if (itemSelecionado == "Lançamentos") {
            val navegaLogin = Intent(this, LancamentosActivity::class.java)
            startActivity(navegaLogin)
        }

        if (itemSelecionado == "Relatorio") {
            val navegaLogin = Intent(this, listaActivity::class.java)
            startActivity(navegaLogin)
        }

        if (itemSelecionado == "Sair") {
            // Logout no Firebase
            FirebaseAuth.getInstance().signOut()

            val navegaLogin = Intent(this, MainActivity::class.java)
            startActivity(navegaLogin)
        }

        return super.onOptionsItemSelected(item)
    }

}