package br.senac.appfinanceiro

import br.senac.appfinanceiro.databinding.ActivityLancamentosBinding
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.senac.appfinanceiro.model.Lancamentos
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class LancamentosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLancamentosBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLancamentosBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_lancamentos)
        setContentView(binding.root)

        binding.btSalvar.setOnClickListener {
            salvar()
        }
     }

    private fun salvar() {
        val data: String = binding.txtData.text.toString().trim { it <= ' ' }
        val historico: String = binding.txtHistorico.text.toString().trim { it <= ' ' }
        val valor: String = binding.txtValor.text.toString().trim { it <= ' ' }
        var tipo: String = ""
        if (binding.rbEntrada.isChecked) {
            tipo = "Entrada"
        } else {
            tipo = "Saída"
        }

        val db = Firebase.firestore

        val mapLancamento = hashMapOf(
            "dtData" to data.toString(),
            "historico" to historico.toString(),
            "valor" to valor.toDouble(),
            "tipo" to tipo.toString()
        )

        db.collection("lancamentos")
            .add(mapLancamento)
            .addOnCompleteListener { acao ->
                if (acao.isSuccessful) {
                    limpaCampos()
                    Toast.makeText(this, "Lançamento inserido com sucesso.", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Ocorreram problemas na gravação.", Toast.LENGTH_LONG).show()
            }
    }

    fun limpaCampos(){
        binding.txtData.setText("")
        binding.txtHistorico.setText("")
        binding.txtValor.setText("")
        binding.rbEntrada.isChecked = true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var itemSelecionado = ""

        when(item?.itemId) {
            R.id.lancamentos -> itemSelecionado = "Lançamentos"
            R.id.relatorio -> itemSelecionado = "Relatorio"
            R.id.sair -> itemSelecionado = "Sair"
        }

        if (itemSelecionado == "Lançamentos") {
            val navegaLogin = Intent(this, LancamentosActivity::class.java)
            startActivity(navegaLogin)
        }

        if (itemSelecionado == "Relatorio") {
            val navegaLogin = Intent(this, listaActivity::class.java)
            startActivity(navegaLogin)
        }

        if (itemSelecionado == "Sair") {
            // Logout no Firebase
            FirebaseAuth.getInstance().signOut()

            val navegaLogin = Intent(this, MainActivity::class.java)
            startActivity(navegaLogin)
        }

        return super.onOptionsItemSelected(item)
    }
}