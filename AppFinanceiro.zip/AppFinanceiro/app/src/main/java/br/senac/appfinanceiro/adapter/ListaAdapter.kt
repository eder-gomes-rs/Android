package br.senac.appfinanceiro.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import br.senac.appfinanceiro.R
import br.senac.appfinanceiro.model.Lancamentos
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.QuerySnapshot

class ListaAdapter(private val lancamentos: List<Lancamentos>, internal val context: Context)
    : RecyclerView.Adapter<ListaAdapter.listaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): listaViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_lista, parent, false)
        return listaViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: listaViewHolder, position: Int) {
        val currentitem = lancamentos[position]

        holder.dtData.text = currentitem.dtData
        holder.historico.text = currentitem.historico
        holder.valor.text = currentitem.valor
    }

    override fun getItemCount(): Int {
        return lancamentos.size
    }

    class listaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var dtData : TextView = itemView.findViewById(R.id.txtData)
        var historico : TextView = itemView.findViewById(R.id.txtHistorico)
        var valor : TextView = itemView.findViewById(R.id.txtValor)
        //var tipo : TextView = itemView.findViewById(R.id.....)
    }

}