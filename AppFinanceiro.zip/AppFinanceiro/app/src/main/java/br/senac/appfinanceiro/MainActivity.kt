package br.senac.appfinanceiro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import br.senac.appfinanceiro.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_main)
        setContentView(binding.root)

        binding.btCadastrar.setOnClickListener{
            val navegaCadastroUsuario = Intent(this, CadastrarActivity::class.java)
            startActivity(navegaCadastroUsuario)
        }

        binding.btEntrar.setOnClickListener{
            when {
                TextUtils.isEmpty(binding.txtEmail.text.toString().trim() { it <= ' ' }) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "E-mail é campo obrigatório.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                TextUtils.isEmpty(binding.txtSenha.text.toString().trim() { it <= ' ' }) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Senha é campo obrigatório.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                else -> {
                    val email: String = binding.txtEmail.text.toString().trim { it <= ' ' }
                    val senha: String = binding.txtSenha.text.toString().trim { it <= ' ' }

                    // Faz login usando o FirebaseAuth
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val intent = Intent(this@MainActivity, LancamentosActivity::class.java)
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                intent.putExtra("user_id", FirebaseAuth.getInstance().currentUser!!.uid)
                                intent.putExtra("email_id", email)
                                startActivity(intent)

                                val navegaLancamentos = Intent(this, LancamentosActivity::class.java)
                                startActivity(navegaLancamentos)
                            } else {
                                Toast.makeText(
                                    this@MainActivity,
                                    task.exception!!.message.toString(),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                }
            }
        }

    }


}