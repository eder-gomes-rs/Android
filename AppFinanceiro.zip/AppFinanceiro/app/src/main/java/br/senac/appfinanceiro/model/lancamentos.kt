package br.senac.appfinanceiro.model

data class Lancamentos (
    var dtData: String?="",
    var historico: String?="",
    var valor: String?="",
    var tipo: String?=""
    )