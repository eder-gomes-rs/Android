package br.senac.appfinanceiro

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import br.senac.appfinanceiro.databinding.ActivityCadastrarBinding
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class CadastrarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastrarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastrarBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btLogin.setOnClickListener{
            val navegaLogin = Intent(this, MainActivity::class.java)
            startActivity(navegaLogin)
        }

        binding.btRegistrar.setOnClickListener{
            when {
                TextUtils.isEmpty(binding.txtEmail.text.toString().trim() { it <= ' ' }) -> {
                    Toast.makeText(
                        this@CadastrarActivity,
                        "E-mail é campo obrigatório.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                TextUtils.isEmpty(binding.txtSenha.text.toString().trim() { it <= ' ' }) -> {
                    Toast.makeText(
                        this@CadastrarActivity,
                        "Senha é campo obrigatório.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                else -> {
                    val email: String = binding.txtEmail.text.toString().trim { it <= ' ' }
                    val senha: String = binding.txtSenha.text.toString().trim { it <= ' ' }

                    // Instancia e registra o usuário no Firebase com o e-mail e senha
                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha)
                        .addOnCompleteListener(

                            OnCompleteListener<AuthResult> { task ->

                                if (task.isSuccessful) {
                                    val firebaseUser: FirebaseUser = task.result!!.user!!

                                    Toast.makeText(
                                        this@CadastrarActivity,
                                        "Usuário registrado com sucesso.",
                                        Toast.LENGTH_LONG
                                    ).show()

                                    val intent = Intent(this@CadastrarActivity, MainActivity::class.java)
                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    intent.putExtra("user_id", firebaseUser.uid)
                                    intent.putExtra("email_id", email)
                                    startActivity(intent)

                                    val navegaLancamentos = Intent(this, LancamentosActivity::class.java)
                                    startActivity(navegaLancamentos)

                                } else {
                                    Toast.makeText(
                                        this@CadastrarActivity,
                                        task.exception!!.message.toString(),
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        )
                }
            }
        }
    }
}


