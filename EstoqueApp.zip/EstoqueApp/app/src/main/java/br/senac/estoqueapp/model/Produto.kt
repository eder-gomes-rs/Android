package br.senac.estoqueapp.model

data class Produto(
    val idProduto: Int = 0,
    var dsProduto: String? = null,
    var quantidade: Int = 0,
    var importado: Int = 0
    )