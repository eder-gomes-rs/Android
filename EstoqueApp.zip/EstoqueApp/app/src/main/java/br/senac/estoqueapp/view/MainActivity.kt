package br.senac.estoqueapp.view

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.senac.estoqueapp.R
import br.senac.estoqueapp.adapter.ListaAdapter
import br.senac.estoqueapp.databinding.ActivityMainBinding
import br.senac.estoqueapp.model.Produto
import br.senac.estoqueapp.repository.databaseHandler

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    var listaAdapter: ListaAdapter? = null
    var linearLayoutManager: LinearLayoutManager? = null

    var produtos: List<Produto> = ArrayList<Produto>()
//    var databaseHandler = databaseHandler(this)

    lateinit var rvEstoque: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        rvEstoque = findViewById(R.id.rvEstoque)




        binding.fab.setOnClickListener { view ->
            val intent = Intent(this, FormularioActivity::class.java)
            intent.putExtra("acao", "inserir")
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        val databaseHandler = databaseHandler(this)
        produtos = databaseHandler.getProdutos()

        listaAdapter = ListaAdapter(produtos, this) { position, action ->
            if (action.equals("editar")) {
                    val intent = Intent(this, FormularioActivity::class.java)
                    intent.putExtra("acao", "editar")
                    intent.putExtra("idProduto", produtos[position].idProduto)
                    startActivity(intent)
            } else { // "excluir"
                databaseHandler.deleteProduto(produtos[position].idProduto)
                produtos = databaseHandler.getProdutos()
                listaAdapter?.notifyDataSetChanged()
            }
        }
        linearLayoutManager = LinearLayoutManager(this)
        rvEstoque.layoutManager = linearLayoutManager
        rvEstoque.adapter = listaAdapter
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return true
    }
}