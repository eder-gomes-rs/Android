package br.senac.estoqueapp.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import androidx.core.view.isVisible
import br.senac.estoqueapp.R
import br.senac.estoqueapp.model.Produto
import br.senac.estoqueapp.repository.databaseHandler

class FormularioActivity : AppCompatActivity() {

    lateinit var etProduto: EditText
    lateinit var etQuantidade: EditText
    lateinit var rbImportado: RadioButton
    lateinit var rbNacional: RadioButton
    lateinit var btSalvar: Button
    lateinit var btExcluir: Button
    lateinit var cbImportado: CheckBox

    var acao: String = ""
    var produto: Produto? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)

        etProduto = findViewById(R.id.etProduto)
        etQuantidade = findViewById(R.id.etQuantidade)
        cbImportado = findViewById(R.id.cbImportado)
        btSalvar = findViewById(R.id.btSalvar)
        btExcluir = findViewById(R.id.btExcluir)

        acao = intent.getStringExtra("acao").toString()

        if ( acao.equals("inserir")){
            produto = Produto()
            btExcluir.isVisible = false
        } else {
            val idProduto = intent.getIntExtra("idProduto", 0)

            // busca o produto no banco
            produto = databaseHandler(this).getProdutoById(idProduto)

            if (produto == null) {
                finish()
            } else {
                carregarFormulario()
            }
        }
    }

    fun carregarFormulario() {
        etProduto.setText( produto?.dsProduto)
        etQuantidade.setText( produto?.quantidade.toString())
        if (produto?.importado!!.equals(1)) {
            cbImportado.isChecked = true
        } else {
            cbImportado.isChecked = false
        }
    }

    fun salvar(view: View){
        produto?.dsProduto = etProduto.text.toString()
        if ( etQuantidade.text.toString().isEmpty() ) {
            produto?.quantidade = 0
        } else {
            produto?.quantidade = etQuantidade.text.toString().toInt()
        }
        if ( cbImportado.isChecked ) {
            produto?.importado = 1
        } else {
            produto?.importado = 0
        }

        val databaseHandler = databaseHandler(this)

        if (acao.equals("inserir")) {
            databaseHandler.addProduto(produto!!)
            etProduto.setText("")
            etQuantidade.setText("")
            cbImportado.isChecked = false
        } else {
            databaseHandler.updateProduto( produto!!)
        }
        finish()
    }

    fun excluir(view: View){
        val databaseHandler = databaseHandler(this)
        databaseHandler.deleteProduto(produto!!.idProduto)
        finish()
    }

    fun cancelar(view: View){
        finish()
    }

}