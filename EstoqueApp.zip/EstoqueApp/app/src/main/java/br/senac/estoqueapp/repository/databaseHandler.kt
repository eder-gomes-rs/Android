package br.senac.estoqueapp.repository

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import br.senac.estoqueapp.model.Produto

class databaseHandler(context: Context): SQLiteOpenHelper(context, NAME, null, VERSION) {
    companion object{
        const val NAME = "dbEstoque"
        const val VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val SQL = "CREATE TABLE IF NOT EXISTS produtos (" +
                  " idProduto INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                  " dsProduto TEXT, " +
                  " quantidade INTEGER, " +
                  " importado INTEGER )"
        db?.execSQL(SQL)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {}

    fun addProduto( produto: Produto): Boolean{
        var db = this.writableDatabase

        val values = ContentValues()
        values.put("dsProduto", produto.dsProduto)
        values.put("quantidade", produto.quantidade)
        values.put("importado", produto.importado)

        val retorno = db.insert("produtos", null, values)
        db.close()

        return retorno >= 0
    }

    fun updateProduto( produto: Produto): Boolean{
        var db = this.writableDatabase

        val values = ContentValues()
        values.put("dsProduto", produto.dsProduto)
        values.put("quantidade", produto.quantidade)
        values.put("importado", produto.importado)

        val retorno = db.update("produtos", values, "idProduto = " + produto.idProduto, null)
        db.close()

        return retorno >= 0
    }

    fun deleteProduto( idProduto: Int): Boolean{
        var db = this.writableDatabase

        val retorno = db.delete("produtos","idProduto = " + idProduto, null)
        db.close()

        return retorno >= 0
    }

    fun getProdutos(): ArrayList<Produto>{

        var lista = ArrayList<Produto>()
        var db = this.readableDatabase

        val query = "SELECT * FROM produtos ORDER BY dsProduto"
        val cursor = db.rawQuery( query, null)

        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()

                do {
                    val idProduto = cursor.getInt( cursor.getColumnIndex("idProduto") )
                    val dsProduto = cursor.getString( cursor.getColumnIndex("dsProduto") )
                    val quantidade = cursor.getInt( cursor.getColumnIndex("quantidade") )
                    val importado = cursor.getInt( cursor.getColumnIndex("importado") )

                    val produto = Produto(idProduto, dsProduto, quantidade, importado)
                    lista.add(produto)

                }while (cursor.moveToNext())

            }
        }

        return lista
    }

    fun getProdutoById(idProduto: Int): Produto?{

        var db = this.readableDatabase

        val query = "SELECT * FROM produtos WHERE idProduto = $idProduto ORDER BY dsProduto"
        val cursor = db.rawQuery( query, null)

        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()

                val idProduto = cursor.getInt( cursor.getColumnIndex("idProduto") )
                val dsProduto = cursor.getString( cursor.getColumnIndex("dsProduto") )
                val quantidade = cursor.getInt( cursor.getColumnIndex("quantidade") )
                val importado = cursor.getInt( cursor.getColumnIndex("importado") )

                val produto = Produto(idProduto, dsProduto, quantidade, importado)
                return produto
            }
        }

        return null
    }


}