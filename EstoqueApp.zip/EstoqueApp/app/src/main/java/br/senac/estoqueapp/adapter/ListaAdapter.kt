package br.senac.estoqueapp.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.senac.estoqueapp.R
import br.senac.estoqueapp.model.Produto

class ListaAdapter(private val produtos: List<Produto>,
                   internal val context: Context,
                   private val callbacks: (Int, String) -> Unit
): RecyclerView.Adapter<ListaAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.content_lista, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val produto = produtos[position]
        holder.tvIdProduto.text = produto.idProduto.toString()
        holder.tvProduto.text = produto.dsProduto
        holder.tvQuantidade.text = produto.quantidade.toString()

        if (produto.importado == 1) {
            holder.tvImportado.text = "Sim"
        } else {
            holder.tvImportado.text = "Não"
        }

        if (position % 2 == 0) {
            holder.layout.setBackgroundColor(Color.rgb(240,240,240))
        } else {
            holder.layout.setBackgroundColor(Color.rgb(255,255,255))
        }

        holder.layout.setOnClickListener {
            this.callbacks(position, "editar")
        }

    }

    override fun getItemCount(): Int {
        return produtos.size
    }

    inner class ViewHolder (view: View): RecyclerView.ViewHolder(view) {
        val tvImportado: TextView = view.findViewById(R.id.tvImportado)
        var tvIdProduto: TextView = view.findViewById(R.id.tvIdProduto)
        var tvProduto: TextView = view.findViewById(R.id.tvProduto)
        var tvQuantidade: TextView = view.findViewById(R.id.tvQuantidade)

        var layout: LinearLayout = view.findViewById(R.id.linearLayout)
    }

}