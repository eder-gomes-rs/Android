package br.senac.crudbasicofirebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    lateinit var _etCodigo: EditText
    lateinit var _etProduto: EditText
    lateinit var _etPreco: EditText

    lateinit var _btSalvar: Button
    lateinit var _btExcluir: Button
    lateinit var _btProcurar: Button

    var _codigo: String = ""
    var _produto: String = ""
    var _preco: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun Procurar(view: View){
        val _etCodigo = findViewById<EditText>(R.id.etCodigo)
        val _etProduto = findViewById<EditText>(R.id.etProduto)
        val _etPreco = findViewById<EditText>(R.id.etPreco)
        _btProcurar = findViewById(R.id.btProcurar)

        val _codigo = _etCodigo.toString()

        val db = FirebaseFirestore.getInstance()
        //val db = Firebase.firestore

        db.collection("produtos").document(_codigo).get()
            .addOnCompleteListener { snap ->
                val _codigo  = snap.result.id.toString()
                val _produto = snap.result.get("produto").toString()
                val _preco = snap.result.get("preco").toString()

                _etCodigo.setText(_codigo)
                _etProduto.setText(_produto)
                _etPreco.setText(_preco)
            }
            .addOnFailureListener{
                Toast.makeText(this, "Ocorreram problemas no acesso aos dados.",Toast.LENGTH_LONG).show()
            }
    }

    fun Salvar(view: View){
        _etCodigo = findViewById(R.id.etCodigo)
        _etProduto = findViewById(R.id.etProduto)
        _etPreco = findViewById(R.id.etPreco)
        _btSalvar = findViewById(R.id.btSalvar)

        _codigo = _etCodigo.text.toString()

        val db = Firebase.firestore

        val mapProduto = hashMapOf(
            "produto" to _etProduto.text.toString(),
            "preco" to _etPreco.text.toString().toInt()
        )

        db.collection("produtos").document(_codigo)
            .set(mapProduto)
            .addOnCompleteListener { acao ->
                if (acao.isSuccessful) {
                    limpaCampos()
                    Toast.makeText(this, "Produto salvo com sucesso.",Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Ocorreram problemas na gravação.",Toast.LENGTH_LONG).show()
            }

    }

    fun Excluir(view: View) {
        _btExcluir = findViewById(R.id.btExcluir)

        val _codigo = _etCodigo.text.toString()

        val db = Firebase.firestore

        db.collection("produtos").document(_codigo)
            .delete()
            .addOnSuccessListener { Log.d("FIREBASE", "DocumentSnapshot successfully deleted!") }
            .addOnFailureListener { e -> Log.w("FIREBASE", "Error deleting document", e) }

        limpaCampos()
    }

    fun limpaCampos(){
        val _etCodigo = findViewById<EditText>(R.id.etCodigo)
        val _etProduto = findViewById<EditText>(R.id.etProduto)
        val _etPreco = findViewById<EditText>(R.id.etPreco)

        _etCodigo.text.clear()
        _etProduto.text.clear()
        _etPreco.text.clear()
    }

}