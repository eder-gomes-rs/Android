# flex-shrink

Define a capacidade de redução de tamanho do item.