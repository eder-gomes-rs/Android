# display: flex;

Torna o elemento um flex container automaticamente transformando todos os seus filhos diretos em flex itens.