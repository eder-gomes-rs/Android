
// window.onload = carregaProdutos();

window.onload = () => {
    buscarProdutos();    
    setInterval(buscarProdutos, 3000); 
}

function buscarProdutos(){
    let xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        const produtos = JSON.parse(this.responseText);

        carregaProdutos( produtos );
    }
    xhttp.open("GET", "http://localhost:3000/produtos");
    xhttp.send();
}

function carregaProdutos( produtos ) {

    // let produto = {
    //     "id" : 1,
    //     "nome" : "Descrição do produto",
    //     "preco" : 100.00,
    //     "imagem" : "pedigree.jpg"
    // }

    let _htmlProdutos = '';
    
    for (let produto of produtos) {

        _htmlProdutos +=

        `<div class="w3-col l4 m6 s12 w3-container w3-padding-16">
            <div class="w3-card">
                <div class="w3-container w3-center">
                    <img src="img/${produto.imagem}" style="width: 70%">
                    <h5>${produto.nome}</h5>
                    <h3 class="w3-blue">R$ ${produto.preco.toLocaleString('pt-br', {minimumFractionDigits:2})}</h3>
                </div>
            </div>
        </div>`
    };

    // document.getElementById("produtos").innerHTML = _html;
    document.querySelector("#produtos").innerHTML = _htmlProdutos;

  }
