package br.com.senac.appcep.model

data class Endereco(
    val cep: String,
    val logradouro: String,
    val localidade: String,
    val uf: String,
    val bairro: String,
    val complemento: String
)


