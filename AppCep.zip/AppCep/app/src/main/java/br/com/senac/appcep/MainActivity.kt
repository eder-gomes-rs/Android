package br.com.senac.appcep

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import br.com.senac.appcep.client.CepClientAPI

class MainActivity : AppCompatActivity() {
    val cepClientAPI: CepClientAPI by lazy {
        CepClientAPI()
    }

    lateinit var _etCEP: EditText
    lateinit var _tvCidade: TextView
    lateinit var _tvUF: TextView
    lateinit var _tvLogradouro: TextView
    lateinit var _tvComplemento: TextView
    lateinit var _tvBairro: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun buscaCEP(view: View){
        val _etCEP = findViewById<EditText>(R.id.etCEP)
        val _tvCidade = findViewById<TextView>(R.id.tvCidade)
        val _tvUF = findViewById<TextView>(R.id.tvUF)
        val _tvLogradouro = findViewById<TextView>(R.id.tvLogradouro)
        val _tvComplemento = findViewById<TextView>(R.id.tvComplemento)
        val _tvBairro = findViewById<TextView>(R.id.tvBairro)

        val cep = _etCEP.text.toString()

        if (cep.length < 8) {
           Toast.makeText(this, "CEP deve conter pelo menos 8 dígitos.", Toast.LENGTH_LONG ).show()
        } else {
            cepClientAPI.buscarEndereco(
                cep,
                onSuccess = {endereco ->
                    _tvCidade.text = endereco?.localidade
                    _tvUF.text = endereco?.uf
                    _tvLogradouro.text = endereco?.logradouro
                    _tvComplemento.text = endereco?.complemento
                    _tvBairro.text = endereco?.bairro
                },
                onFail = {erro ->
                    Toast.makeText(this, erro, Toast.LENGTH_LONG ).show()
                }
            )
        }
    }
}