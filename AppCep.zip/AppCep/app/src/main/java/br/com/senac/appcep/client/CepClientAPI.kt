package br.com.senac.appcep.client

import br.com.senac.appcep.model.Endereco
import br.com.senac.appcep.service.CepService
import br.com.senac.appcep.utils.APIUtils
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CepClientAPI (val cepService: CepService = APIUtils().cepService) {

    fun buscarEndereco(
        cep: String,
        onSuccess: (endereco: Endereco?) -> Unit,
        onFail: (erro: String?) -> Unit
        ) {
        cepService.buscarEndereco(cep).enqueue(object : Callback<Endereco>{
            override fun onResponse(call: Call<Endereco>, response: Response<Endereco>) {
                if (response.isSuccessful)
                    onSuccess(response.body())
                else
                    onFail("Erro não identificado.")
            }

            override fun onFailure(call: Call<Endereco>, t: Throwable) {
                onFail(t.message)
            }
        })
    }
}