import React from "react";
import Card from "./Card";

export default function ListProdutos({produtos}) {
    return (
        <section class="w3-row w3-container w3-margin-top">
            {
                produtos.map( prod => 
                    <Card key={prod.id} produto = {prod}>
                    </Card>
                )
            }
        </section>
    )
}
