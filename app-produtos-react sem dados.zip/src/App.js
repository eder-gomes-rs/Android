
import './App.css';
import produtos from './data/produtos.json'
import ListProdutos from './components/ListProdutos';
import Carroussel from './components/Carroussel';
import Menu from './components/Menu';


function App() {
  return (
    <>
      <Menu></Menu>

      <main>
        <div className="App">

          <div id="produtos" class="w3-container w3-padding-16 w3-margin-top">
            <h1>Exercício</h1>
              <Carroussel></Carroussel>

              <ListProdutos produtos = {produtos} >
              </ListProdutos>

          </div>

        </div>
      </main>
    </>
  );
}

export default App;
