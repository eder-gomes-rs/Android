# Dicas de Ferramentas para desenvolvimento front-end


## Editar, recortar, redimensionar imagens - online
https://www.iloveimg.com/


## Gerador de gradientes
https://mycolor.space/
